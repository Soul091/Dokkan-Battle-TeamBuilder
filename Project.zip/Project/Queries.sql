.headers ON
--Q1 Display all Super AGL Types
-- SELECT Title, Character, Type
-- FROM DokkanCards
-- WHERE Type = 'Super AGL';

--Q2 Creates new team tables
-- Create Table Team2(
--     Title varchar(117),
--     Characters varchar(117),
--     Categories varchar(117),
--     Links varchar(117),
--     Type varchar(117)
-- );
-- Create Table Team3(
-- --     Title varchar(117),
-- --     Characters varchar(117),
-- --     Categories varchar(117),
-- --     Links varchar(117),
-- --     Type varchar(117)
-- -- );

--Q3 Insert data into Team 1, Team2, and Team3
-- INSERT INTO Team1 (Title, Characters,Categories, Links, Type)
-- SELECT Title,Character,Categories, Links, Type
-- FROM DokkanCards
-- WHERE Categories LIKE '%Super Saiyan%'
-- ORDER BY RANDOM()
-- LIMIT 6;

-- INSERT INTO Team2 (Title, Characters,Categories, Links, Type)
-- SELECT Title,Character,Categories, Links, Type
-- FROM DokkanCards
-- WHERE Categories LIKE '%Fusion%'
-- ORDER BY RANDOM()
-- LIMIT 6;

-- INSERT INTO Team3 (Title, Characters,Categories, Links, Type)
-- Select Title, Character, Categories, Links, Type
-- from DokkanCards
-- Where Categories like '%Android%'
-- ORDER BY RANDOM()
-- LIMIT 6;

--Q4 Completely Drops data from all 3 teams
-- Delete from Team1;

-- Delete from Team2;

-- Delete from Team3;

--Q5 Updates password for user
-- UPDATE Users
-- set UserPassword = 12468                                 
-- where UserID = 1;

--Q6 Displays the Charcters ID from Team3
-- SELECT Characters, ID
-- FROM DokkanCards,Team3
-- WHERE Team3.Title = DokkanCards.Title
-- and Team3.Characters = DokkanCards.Character;

--Q7 Select Post using the Username from Users
-- SELECT P_UserName
-- FROM Posts,Users
-- WHERE Users.UserName = Posts.P_UserName;

--Q8 Display How many Likes A user got on his comment
SELECT UserName, c_Comment, CommentLikes
FROM Comment_Likes,Comments,Users, Posts
WHERE Users.UserId = Comments.cp_id
and Comments.comment_ID = Comment_Likes.commentLikes_ID;

--Q9 Total Units whos type are Extreme AGL and Extreme INT
-- select count(type) as 'Extreme AGL/INT'
-- from DokkanCards
-- where Type = 'Extreme AGL'
-- or Type = 'Extreme INT';

--Q10 Total HP from Team3
-- select sum(HP) as 'Total HP', sum(Attack) as 'Total Attack', sum(Defense) as 'Total Defense'
-- from Team3, DokkanCards
-- where Team3.Title = DokkanCards.Title
-- and Team3.Characters = DokkanCards.Character;


--Q11 Unit With Highest EZA Attack
-- SELECT Title,Character,MAX(EZAAttack)
-- FROM DokkanCards
-- WHERE EZAAttack != '';

--Q12 Find Average Attack across all characters
-- select avg(Attack)
-- from DokkanCards;

--Q11 List of Links from a Users Team
-- select links
-- from Team3;

--Q13 Bring up Most Liked Post or Comment?

--Q14 Display Units that have a Transformation type of Fusion
-- SELECT Title, Character, TransformationType
-- FROM DokkanCards
-- WHERE TransformationType LIKE '%Fusion%';

--Q15 Displays Count of Units with Type Extreme AGL who have the Link Fierce Battle
-- SELECT COUNT(Character) as 'Units With Fierce Battle Link and Type Extreme AGL'
-- FROM DokkanCards
-- WHERE Type = 'Extreme AGL'
-- AND Links LIKE '%Fierce Battle%';

--Q16 Display How many Characters Share the Name Goku Or Vegeta PS Gotta work on this

--Q17 Display Count of Followers For User

--Q18 Display all UserNames who Follow a User

--Q19 Display Sum of HP, ATK, DEF for A Posts Team and the User who posted it

--Q20 Display All things a User Liked whether it be Comments or Posts

--Q21 Select All Units From a Team who dont have a specific Link or Type From A Post

import sqlite3
from sqlite3 import Error
from sqlite3.dbapi2 import Cursor

def openConnection(_dbFile):
    print("++++++++++++++++++++++++++++++++++")
    print("Open database: ", _dbFile)

    conn = None
    try:
        conn = sqlite3.connect(_dbFile)
        print(" success")
    except Error as e:
        print(e)

    print("++++++++++++++++++++++++++++++++++")

    return conn

def closeConnection(_conn, _dbFile):
    print("++++++++++++++++++++++++++++++++++")
    print("Close database: ", _dbFile)

    try:
        _conn.close()
        print("success")
    except Error as e:
        print(e)

    print("++++++++++++++++++++++++++++++++++")

##########    
#HOMEPAGE#  
##########  
def Homepage(_conn):
    print("++++++++++++++++++++++++++++++++++")

    out = """Do you want to Log In or Create an Account:
    1. Create Account
    2. Log In"""
    
    print(out)
    choice = input()
    
    if (choice == '1'):
        Createaccount(_conn)
    elif (choice == '2'):
        login(_conn)
    else:
        print("Please try again with a valid input")
        Homepage(_conn)

##################
# Create Account #
##################    
def Createaccount(_conn):
    print("++++++++++++++++++++++++++++++++++")
    cursor = _conn.cursor()
    UserName = input('Enter New User: ')
    UserPassword = input('Enter New Password: ')
    Email = input('Enter New Email: ')
    cursor.execute("""
    INSERT INTO Users(UserName, UserPassword, Email)
    VALUES (?, ?, ?)
    """, (UserName, UserPassword, Email))
    _conn.commit()
    print('Succesfully Added New User')
    # _conn.close()
    Homepage(_conn)
    
#########    
# Login #
#########
def login(_conn):
    print("++++++++++++++++++++++++++++++++++")
    UserName = input('Enter User: ')
    UserPassword = input('Enter Password: ')
    cur = _conn.cursor()
    statement = f"SELECT UserName FROM Users WHERE UserName = '{UserName}' AND UserPassword = '{UserPassword}';"
    cur.execute(statement)
    if not cur.fetchone():
        print("Wrong User/Password Try Again")
        login(_conn)
    else:
        Menu(_conn)

#############    
# Main Menu #
#############  
def Menu(_conn):
    print("++++++++++++++++++++++++++++++++++")
    
    out = """Please enter in a choice that you want to complete:
    1. Create Team
    2. Update Team
    3. Delete Team
    4. Search Through Units
    5. Go To Posts
    6. Logout"""

    print(out)
    choice = input()
    
    if (choice == '1'):
        Create(_conn)
    elif (choice == '2'):
        Update(_conn)
    elif (choice == '3'):
        Delete(_conn)
    elif (choice == '4'):
        Units(_conn)
    elif (choice == '5'):
        Posts(_conn)
    elif (choice == '6'):
        logout(_conn)
    else:
        print("Please try again with a valid choice")
        Menu(_conn)

###############
# Create Team #
###############        
def Create(_conn):
    print("++++++++++++++++++++++++++++++++++")
    
    out = """Please enter Which Unit You would like to add:
    1. Insert First Unit
    2. Back to Menu"""

    print(out)
    choice = input()
    
    if (choice == '1'):
        insert1(_conn)
    elif (choice == '2'):
        Menu(_conn)
    else:
        print("Please try again with a valid choice")
        Create(_conn)
    

def insert1(_conn):
    print("++++++++++++++++++++++++++++++++++")

    out = """Please insert a Valid ID for First Unit:
    """
    print(out)

    # cursor = _conn.cursor()
    # choice = input('Enter Valid ID: ')
    # cursor.execute("""
    # INSERT INTO TeamData(UnitTitle, UnitCharacter, UnitType, UnitCatagories, UnitID) SELECT Title, Character, Type, Categories, ID FROM DokkanCards WHERE ID = ? LIMIT 1; VALUES (?)
    # """, (choice))
    # _conn.commit()
    # print('Succesfully Added New User')
    # _conn.close()
    # insert2(_conn)
    
    # out = """Please insert a Valid ID for First Unit:
    # """
    # print(out)
    # choice = input('Enter First Unit Id: ')
    try:
        sql = """Insert INTO TeamData(UnitID) VALUES (?)
        """
        _UnitID = int(input("Enter Unit ID:"))
        args = [_UnitID]
        sql2 = """
        UPDATE TeamData
        SET UnitTitle = (SELECT Title FROM DokkanCards,TeamData where ID = ?);
        """
        sql3 = """
        UPDATE TeamData
        SET UnitCharacter = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
        """
        sql4 = """
        UPDATE TeamData
        SET UnitType = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
        """
        sql5 = """
        UPDATE TeamData
        SET UnitCatagories = (SELECT Categories FROM DokkanCards,TeamData where ID = ?);
        """
        sql6 = """
        UPDATE TeamData
        SET UnitID = (SELECT ID FROM DokkanCards,TeamData where ID = ?);
        """
        _conn.execute(sql,args)
        _conn.execute(sql2,args)
        _conn.execute(sql3,args)
        _conn.execute(sql4,args)
        _conn.execute(sql5,args)
        _conn.execute(sql6,args)
        _conn.commit()
        insert2(_conn)
    except Error as e:
        print(e)
        
        
    
def insert2(_conn):
    print("++++++++++++++++++++++++++++++++++")

    out = """Please insert a Valid ID for Second Unit:
    """
    print(out)
    try:
        #sql = """Insert INTO TeamData(UnitID) VALUES (?)
        #"""
        _UnitID = int(input("Enter Unit ID:"))
        args = [_UnitID]
        sql2 = """
        UPDATE TeamData
        SET UnitTitle2 = (SELECT Title FROM DokkanCards,TeamData where ID = ?);
        """
        sql3 = """
        UPDATE TeamData
        SET UnitCharacter2 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
        """
        sql4 = """
        UPDATE TeamData
        SET UnitType2 = (SELECT Type FROM DokkanCards,TeamData where ID = ?);
        """
        sql5 = """
        UPDATE TeamData
        SET UnitCatagories2 = (SELECT Categories FROM DokkanCards,TeamData where ID = ?);
        """
        sql6 = """
        UPDATE TeamData
        SET UnitID2 = (SELECT ID FROM DokkanCards,TeamData where ID = ?);
        """
       ## _conn.execute(sql,args)
        _conn.execute(sql2,args)
        _conn.execute(sql3,args)
        _conn.execute(sql4,args)
        _conn.execute(sql5,args)
        _conn.execute(sql6,args)
        _conn.commit()
        insert3(_conn)
    except Error as e:
        print(e)
        
        
        


def insert3(_conn):
    print("++++++++++++++++++++++++++++++++++")
    
    out = """Please insert a Valid ID for Third Unit:
    """
    print(out)
    
    try:
        #sql = """Insert INTO TeamData(UnitID) VALUES (?)
       # """
        _UnitID = int(input("Enter Unit ID:"))
        args = [_UnitID]
        sql2 = """
        UPDATE TeamData
        SET UnitTitle3 = (SELECT Title FROM DokkanCards,TeamData where ID = ?);
        """
        sql3 = """
        UPDATE TeamData
        SET UnitCharacter3 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
        """
        sql4 = """
        UPDATE TeamData
        SET UnitType3 = (SELECT Type FROM DokkanCards,TeamData where ID = ?);
        """
        sql5 = """
        UPDATE TeamData
        SET UnitCatagories3 = (SELECT Categories FROM DokkanCards,TeamData where ID = ?);
        """
        sql6 = """
        UPDATE TeamData
        SET UnitID3 = (SELECT ID FROM DokkanCards,TeamData where ID = ?);
        """
       ## _conn.execute(sql,args)
        _conn.execute(sql2,args)
        _conn.execute(sql3,args)
        _conn.execute(sql4,args)
        _conn.execute(sql5,args)
        _conn.execute(sql6,args)
        _conn.commit()
        insert4(_conn)
    except Error as e:
        print(e)
        
        

def insert4(_conn):
    print("++++++++++++++++++++++++++++++++++")
    
    out = """Please insert a Valid ID for Fourth Unit:
    """
    print(out)
    try:
       # sql = """Insert INTO TeamData(UnitID) VALUES (?)
      #  """
        _UnitID = int(input("Enter Unit ID:"))
        args = [_UnitID]
        sql2 = """
        UPDATE TeamData
        SET UnitTitle4 = (SELECT Title FROM DokkanCards,TeamData where ID = ?);
        """
        sql3 = """
        UPDATE TeamData
        SET UnitCharacter4 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
        """
        sql4 = """
        UPDATE TeamData
        SET UnitType4 = (SELECT Type FROM DokkanCards,TeamData where ID = ?);
        """
        sql5 = """
        UPDATE TeamData
        SET UnitCatagories4 = (SELECT Categories FROM DokkanCards,TeamData where ID = ?);
        """
        sql6 = """
        UPDATE TeamData
        SET UnitID4 = (SELECT ID FROM DokkanCards,TeamData where ID = ?);
        """
       # _conn.execute(sql,args)
        _conn.execute(sql2,args)
        _conn.execute(sql3,args)
        _conn.execute(sql4,args)
        _conn.execute(sql5,args)
        _conn.execute(sql6,args)
        _conn.commit()
        insert5(_conn)
    except Error as e:
        print(e)
        
        

def insert5(_conn):
    print("++++++++++++++++++++++++++++++++++")
    
    out = """Please insert a Valid ID for Fifth Unit:
    """
    print(out)
    
    try:
       # sql = """Insert INTO TeamData(UnitID) VALUES (?)
       # """
        _UnitID = int(input("Enter Unit ID:"))
        args = [_UnitID]
        sql2 = """
        UPDATE TeamData
        SET UnitTitle5 = (SELECT Title FROM DokkanCards,TeamData where ID = ?);
        """
        sql3 = """
        UPDATE TeamData
        SET UnitCharacter5 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
        """
        sql4 = """
        UPDATE TeamData
        SET UnitType5 = (SELECT Type FROM DokkanCards,TeamData where ID = ?);
        """
        sql5 = """
        UPDATE TeamData
        SET UnitCatagories5 = (SELECT Categories FROM DokkanCards,TeamData where ID = ?);
        """
        sql6 = """
        UPDATE TeamData
        SET UnitID5 = (SELECT ID FROM DokkanCards,TeamData where ID = ?);
        """
       # _conn.execute(sql,args)
        _conn.execute(sql2,args)
        _conn.execute(sql3,args)
        _conn.execute(sql4,args)
        _conn.execute(sql5,args)
        _conn.execute(sql6,args)
        _conn.commit()
        insert6(_conn)
    except Error as e:
        print(e)
        
        

def insert6(_conn):
    print("++++++++++++++++++++++++++++++++++")
    
    out = """Please insert a Valid ID for Final Unit:
    """
    print(out)
    
    try:
    
        _UnitID = int(input("Enter Unit ID:"))
        args = [_UnitID]
        sql2 = """
        UPDATE TeamData
        SET UnitTitle6 = (SELECT Title FROM DokkanCards,TeamData where ID = ?);
        """
        sql3 = """
        UPDATE TeamData
        SET UnitCharacter6 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
        """
        sql4 = """
        UPDATE TeamData
        SET UnitType6 = (SELECT Type FROM DokkanCards,TeamData where ID = ?);
        """
        sql5 = """
        UPDATE TeamData
        SET UnitCatagories6 = (SELECT Categories FROM DokkanCards,TeamData where ID = ?);
        """
        sql6 = """
        UPDATE TeamData
        SET UnitID6 = (SELECT ID FROM DokkanCards,TeamData where ID = ?);
        """
        #_conn.execute(sql,args)
        _conn.execute(sql2,args)
        _conn.execute(sql3,args)
        _conn.execute(sql4,args)
        _conn.execute(sql5,args)
        _conn.execute(sql6,args)
        _conn.commit()
        Menu(_conn)
    except Error as e:
        print(e)
        
        


def Update(_conn):
    print("++++++++++++++++++++++++++++++++++")
    # Select TeamID from TeamData Where userInput IN (SELECT TEAMID FROM TeamData)
    out = """Would You like to update a team?
    1. Yes
    2. Return To Menu
    """

    print(out)
    choice = input()
    
    if (choice == '1'):
        updating1(_conn)
    elif (choice == '2'):
        Menu(_conn)
    else:
        print("Please try again with a valid choice")
        Update(_conn)


def updating1(_conn):
    print("++++++++++++++++++++++++++++++++++")
    
    out = """Do you want to change this unit enter 1 for yes and 2 to skip
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
        try:
            sql = """Insert INTO TeamData(UnitID) VALUES (?)
            """
            _UnitID = int(input("Enter Unit ID:"))
            args = [_UnitID]
            sql2 = """
            UPDATE TeamData
            SET UnitTitle = (SELECT Title FROM DokkanCards,TeamData where ID = ?);
            """
            sql3 = """
            UPDATE TeamData
            SET UnitCharacter = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
            """
            sql4 = """
            UPDATE TeamData
            SET UnitType = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
            """
            sql5 = """
            UPDATE TeamData
            SET UnitCatagories = (SELECT Categories FROM DokkanCards,TeamData where ID = ?);
            """
            sql6 = """
            UPDATE TeamData
            SET UnitID = (SELECT ID FROM DokkanCards,TeamData where ID = ?);
            """
       # _conn.execute(sql,args)
            _conn.execute(sql2,args)
            _conn.execute(sql3,args)
            _conn.execute(sql4,args)
            _conn.execute(sql5,args)
            _conn.execute(sql6,args)
            _conn.commit()
            updating2(_conn)
        except Error as e:
            print(e)
    elif(choice == '2'):
        updating2(_conn)
        

def updating2(_conn):
    print("++++++++++++++++++++++++++++++++++")
    
    out = """Do you want to change this unit enter 1 for yes and 2 to skip
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
        try:
            sql = """Insert INTO TeamData(UnitID) VALUES (?)
            """
            _UnitID = int(input("Enter Unit ID:"))
            args = [_UnitID]
            sql2 = """
            UPDATE TeamData
            SET UnitTitle2 = (SELECT Title FROM DokkanCards,TeamData where ID = ?);
            """
            sql3 = """
            UPDATE TeamData
            SET UnitCharacter2 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
            """
            sql4 = """
            UPDATE TeamData
            SET UnitType2 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
            """
            sql5 = """
            UPDATE TeamData
            SET UnitCatagories2 = (SELECT Categories FROM DokkanCards,TeamData where ID = ?);
            """
            sql6 = """
            UPDATE TeamData
            SET UnitID2 = (SELECT ID FROM DokkanCards,TeamData where ID = ?);
            """
       # _conn.execute(sql,args)
            _conn.execute(sql2,args)
            _conn.execute(sql3,args)
            _conn.execute(sql4,args)
            _conn.execute(sql5,args)
            _conn.execute(sql6,args)
            _conn.commit()
            updating3(_conn)
        except Error as e:
            print(e)
    elif(choice == '2'):
        updating3(_conn)
        


def updating3(_conn):
    print("++++++++++++++++++++++++++++++++++")
    
    out = """Do you want to change this unit enter 1 for yes and  to skip
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
        try:
            sql = """Insert INTO TeamData(UnitID) VALUES (?)
            """
            _UnitID = input("Enter Unit ID:")
            args = [_UnitID]
            sql2 = """
            UPDATE TeamData
            SET UnitTitle3 = (SELECT Title FROM DokkanCards,TeamData where ID = ?);
            """
            sql3 = """
            UPDATE TeamData
            SET UnitCharacter3 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
            """
            sql4 = """
            UPDATE TeamData
            SET UnitType3 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
            """
            sql5 = """
            UPDATE TeamData
            SET UnitCatagories3 = (SELECT Categories FROM DokkanCards,TeamData where ID = ?);
            """
            sql6 = """
            UPDATE TeamData
            SET UnitID3 = (SELECT ID FROM DokkanCards,TeamData where ID = ?);
            """
       # _conn.execute(sql,args)
            _conn.execute(sql2,args)
            _conn.execute(sql3,args)
            _conn.execute(sql4,args)
            _conn.execute(sql5,args)
            _conn.execute(sql6,args)
            _conn.commit()
            updating4(_conn)
        except Error as e:
            print(e)
    elif(choice == '2'):
        updating4(_conn)
        


def updating4(_conn):
    print("++++++++++++++++++++++++++++++++++")
    
    out = """Do you want to change this unit enter 1 for yes and  to skip
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
        try:
            _UnitID = input("Enter Unit ID:")
            args = [_UnitID]
            sql2 = """
            UPDATE TeamData
            SET UnitTitle4 = (SELECT Title FROM DokkanCards,TeamData where ID = ?);
            """
            sql3 = """
            UPDATE TeamData
            SET UnitCharacter4 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
            """
            sql4 = """
            UPDATE TeamData
            SET UnitType4 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
            """
            sql5 = """
            UPDATE TeamData
            SET UnitCatagories4 = (SELECT Categories FROM DokkanCards,TeamData where ID = ?);
            """
            sql6 = """
            UPDATE TeamData
            SET UnitID4 = (SELECT ID FROM DokkanCards,TeamData where ID = ?);
            """
       # _conn.execute(sql,args)
            _conn.execute(sql2,args)
            _conn.execute(sql3,args)
            _conn.execute(sql4,args)
            _conn.execute(sql5,args)
            _conn.execute(sql6,args)
            _conn.commit()
            updating5(_conn)
        except Error as e:
            print(e)
    elif(choice == '2'):
        updating5(_conn)
        


def updating5(_conn):
    print("++++++++++++++++++++++++++++++++++")
    
    out = """Do you want to change this unit enter 1 for yes and  to skip
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
        try:
            sql = """Insert INTO TeamData(UnitID) VALUES (?)
            """
            _UnitID = input("Enter Unit ID:")
            args = [_UnitID]
            sql2 = """
            UPDATE TeamData
            SET UnitTitle5 = (SELECT Title FROM DokkanCards,TeamData where ID = ?);
            """
            sql3 = """
            UPDATE TeamData
            SET UnitCharacter5 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
            """
            sql4 = """
            UPDATE TeamData
            SET UnitType5 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
            """
            sql5 = """
            UPDATE TeamData
            SET UnitCatagories5 = (SELECT Categories FROM DokkanCards,TeamData where ID = ?);
            """
            sql6 = """
            UPDATE TeamData
            SET UnitID5 = (SELECT ID FROM DokkanCards,TeamData where ID = ?);
            """
       # _conn.execute(sql,args)
            _conn.execute(sql2,args)
            _conn.execute(sql3,args)
            _conn.execute(sql4,args)
            _conn.execute(sql5,args)
            _conn.execute(sql6,args)
            _conn.commit()
            updating6(_conn)
        except Error as e:
            print(e)
    elif(choice == '2'):
        updating6(_conn)

def updating6(_conn):
    print("++++++++++++++++++++++++++++++++++")
    
    out = """Do you want to change this unit enter 1 for yes and  to skip
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
        try:
            sql = """Insert INTO TeamData(UnitID) VALUES (?)
            """
            _UnitID = input("Enter Unit ID:")
            args = [_UnitID]
            sql2 = """
            UPDATE TeamData
            SET UnitTitle6 = (SELECT Title FROM DokkanCards,TeamData where ID = ?);
            """
            sql3 = """
            UPDATE TeamData
            SET UnitCharacter6 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
            """
            sql4 = """
            UPDATE TeamData
            SET UnitType6 = (SELECT Character FROM DokkanCards,TeamData where ID = ?);
            """
            sql5 = """
            UPDATE TeamData
            SET UnitCatagories6 = (SELECT Categories FROM DokkanCards,TeamData where ID = ?);
            """
            sql6 = """
            UPDATE TeamData
            SET UnitID6 = (SELECT ID FROM DokkanCards,TeamData where ID = ?);
            """
       # _conn.execute(sql,args)
            _conn.execute(sql2,args)
            _conn.execute(sql3,args)
            _conn.execute(sql4,args)
            _conn.execute(sql5,args)
            _conn.execute(sql6,args)
            _conn.commit()
            Menu(_conn)
        except Error as e:
            print(e)
    elif(choice == '2'):
        Menu(_conn)




def Delete(_conn):
    print("++++++++++++++++++++++++++++++++++")
    
    out = """Would You like to delete a Team:
    1. Enter 1 for Yes
    2. Enter 2 to Return to Menu
    """
    
    print(out)
    choice = input()
    
    if (choice == '1'):
        Doom(_conn)
    elif (choice == '2'):
        Menu(_conn)
    else:
        print("Please try again with a valid choice")
        Delete(_conn)

def Random(_conn):
    print("++++++++++++++++++++++++++++++++++")


def Doom(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """Do you want to delete a team enter 1 for yes and 2 for no:
    """
    print(out)
    choice = input()
    if(choice =='1'):
        try:
            out = """Enter Team ID to delete that Team:
            """
            print(out)
            _Teamid = input()
            args = [_Teamid]
            sql = "Delete FROM TeamData WHERE TeamID = ?;"
            _conn.execute(sql,args)
            _conn.commit()
            Menu(_conn)
        except Error as e:
            print(e)
    elif(choice == '2'):
        Menu(_conn)
    elif(choice != '1' or choice != '2'):
        print("Please try again with a valid choice")
        Doom(_conn)

def Posts(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """Post Menu:
    1. View Posted Team
    2. Search for a User's Posts
    3. Go Back to Menu
    """
    
    print(out)
    choice = input()
    
    if (choice == '1'):
        #Display username of post and team and comments in seperate sqls
        Postedteam(_conn)
    elif (choice == '2'):
        # Search for a post by the post ID and display the username of post and team and comments
        Postedteam(_conn)
    elif (choice == '3'):
        Menu(_conn)
    else:
        print("Please try again with a valid choice")
        Posts(_conn)
        
def Postedteam(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """What Do you Want to Do on This Post:
    1. Like post
    2. Like Comment
    3. Go Back to Posts
    """
    
    print(out)
    choice = input()
    
    if (choice == '1'):
        #Increment Post Like Counter
        Postedteam(_conn)
    elif (choice == '2'):
        #Increment Comment Like Counter
        Postedteam(_conn)
    elif (choice == '3'):
        Posts(_conn)
    else:
        print("Please try again with a valid choice")
        Postedteam(_conn)
    

def Units(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """How Do you Want to Search Through the Units:
    1. Search By Catagories
    2. Search By Links
    3. Search By Type
    4. Search By HP
    5. Search By Attack
    6. Search By Defense
    7. Search By EZAHP
    8. Search By EZAAttack
    9. Search By EZADefense
    10. Search By TransformationType
    11. Search By SpecialSkill
    12. Back To Menu
    """
    
    print(out)
    choice = input()
    
    if (choice == '1'):
        Display1(_conn)
    if (choice == '2'):
        Display2(_conn)
    if (choice == '3'):
        Display3(_conn)
    if (choice == '4'):
        Display4(_conn)
    if (choice == '5'):
        Display5(_conn)
    if (choice == '6'):
        Display6(_conn)
    if (choice == '7'):
        Display7(_conn)
    if (choice == '8'):
        Display8(_conn)
    if (choice == '9'):
        Display9(_conn)
    if (choice == '10'):
        Display10(_conn)
    if (choice == '11'):
        Display11(_conn)
    if (choice == '12'):
        Menu(_conn)
    else:
        print("Please try again with a valid choice")
        Units(_conn)
        

def Display1(_conn):
    print("++++++++++++++++++++++++++++++++++")
    
    print("Enter a Catagory You are Looking For: ")
    choice = input()
    mycursor = _conn.cursor()
    mycursor.execute("SELECT Title, Character, Type, Categories, ID FROM DokkanCards WHERE Categories = '{choice}'")
    myresult = mycursor.fetchall()
    for x in myresult:print(x)
        
def Display2(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """Search Through Units Through Link 1 for YES and 2 for NO:
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
        try:
            _Link = input("Enter Link name:")
            args = [_Link]
            sql = """SELECT Title,Character, Type, Categories, ID
                    FROM DokkanCards
                    WHERE Links LIKE '('% ? %'';
            """
            _conn.execute(sql,args)
            _conn.commit()
        except Error as e:
            print(e)
        Menu(_conn)
    else:
        print("Please try again with a valid choice")
        Display2(_conn)
        
def Display3(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """Enter a Type You are Looking For:
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
    #-- SELECT Title,Character, Type, Categories, ID
    # -- FROM DokkanCards
    # -- WHERE Link LIKE '%Youth%'
        Units(_conn)
    else:
        print("Please try again with a valid choice")
        Display3(_conn)

def Display4(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """Enter either Max HP or Min HP You are Looking For:
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
    #-- SELECT Title,Character, Type, Categories, ID, MAX(HP)/ MIN(HP)
    # -- FROM DokkanCards
    # -- order in ASC for max or Dec for Min
        Units(_conn)
    else:
        print("Please try again with a valid choice")
        Display4(_conn)

def Display5(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """Enter either MAX Attack or MIN Attack You are Looking For:
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
    #-- SELECT Title,Character, Type, Categories, ID
    # -- FROM DokkanCards
    # -- WHERE Link LIKE '%Youth%'
        Units(_conn)
    else:
        print("Please try again with a valid choice")
        Display5(_conn)

def Display6(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """Enter Either Max or Min Defense You are Looking For:
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
    #-- SELECT Title,Character, Type, Categories, ID Max or MIN
    # -- FROM DokkanCards
    # -- WHERE Link LIKE '%Youth%'
        Units(_conn)
    else:
        print("Please try again with a valid choice")
        Display6(_conn)
        
def Display7(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """Enter either MAX/MIN EZA HP  You are Looking For:
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
    #-- SELECT Title,Character, Type, Categories, ID
    # -- FROM DokkanCards
    # -- WHERE Link LIKE '%Youth%'
        Units(_conn)
    else:
        print("Please try again with a valid choice")
        Display7(_conn)
        
def Display8(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """Enter Either MAX/MIN EZA Defense fr You are Looking For:
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
    #-- SELECT Title,Character, Type, Categories, ID
    # -- FROM DokkanCards
    # -- WHERE Link LIKE '%Youth%'
        Units(_conn)
    else:
        print("Please try again with a valid choice")
        Display8(_conn)
        
def Display9(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """Enter Either MAX/MIN EZA Defense You are Looking For:
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
    #-- SELECT Title,Character, Type, Categories, ID
    # -- FROM DokkanCards
    # -- WHERE Link LIKE '%Youth%'
        Units(_conn)
    else:
        print("Please try again with a valid choice")
        Display9(_conn)

def Display10(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """Enter a TransformationType You are Looking For:
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
    #-- SELECT Title,Character, Type, Categories, ID
    # -- FROM DokkanCards
    # -- WHERE Transformation Type
        Units(_conn)
    else:
        print("Please try again with a valid choice")
        Display10(_conn)
        
def Display11(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """Enter a Link You are Looking For:
    """
    print(out)
    choice = input()
    
    if (choice == '1'):
    #-- SELECT Title,Character, Type, Categories, ID
    # -- FROM DokkanCards
    # -- WHERE Link LIKE '%Youth%'
        Units(_conn)
    else:
        print("Please try again with a valid choice")
        Display11(_conn)
        
def logout(_conn):
    print("++++++++++++++++++++++++++++++++++")
    out = """Are you Sure you Want to Log Out?
    1. Yes
    2. No
    """
    
    print(out)
    choice = input()
    
    if (choice == '1'):
        #Increment Post Like Counter
        exit()
    elif (choice == '2'):
        #Increment Comment Like Counter
        Menu(_conn)
    else:
        print("Please try again with a valid choice")
        logout(_conn)

def main():
    database = r"Project.db"

    # create a database connection
    conn = openConnection(database)
    with conn:
        Homepage(conn)

    closeConnection(conn, database)

if __name__ == '__main__':
    main()

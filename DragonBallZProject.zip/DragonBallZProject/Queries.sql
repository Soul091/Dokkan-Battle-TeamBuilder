.headers ON
--Q1 Display all Super AGL Types
--SELECT Title, Character
--FROM dbz
--WHERE Type = 'Super AGL';

--Q2 Display All Units that contain Goku in the name
--SELECT Title, Character
--FROM dbz
--WHERE Character LIKE '%Goku%';

--Q3 Display Super Attacks that lowers ATK
--SELECT Title,Character
--FROM dbz
--WHERE SuperAttackEffect LIKE '%lowers ATK%';

--Q4 Display Units with Attack greater than 17000
--SELECT Character
--FROM dbz
--WHERE Attack > 17000;

--Q5 Display Units with Sworn Enemies Catagories
--SELECT Title, Character
--FROM dbz
--WHERE Categories LIKE '%Sworn Enemies%';

--Q6 Display AVG EZA ATTACK for EZA units
--SELECT Title, Character, AVG(EZAAttack)
--FROM dbz;

--Q7 Insert unit into Team
--INSERT into Team
--VALUES ('Mystery Super Technique', 'Super Saiyan 3 Goku', '120/140', 15 , 'UR', 'Super AGL',1321); 

--Q8 Update Unit to show you change in lvl for that unit on the team
--UPDATE Team
--SET MaxLevel = '140/140'
--WHERE Id = 1321;

--Q9 Delete Unit to remove it from the Team
--DELETE 
--FROM Team
--WHERE Id = 1321;

--Q10 Display Units that have a Transformation type of Fusion
--SELECT Title, Character
--FROM dbz
--WHERE TransformationType LIKE '%Fusion%';

--Q11 Display Count of Units
--SELECT COUNT(Character) as Units_With_Name_Goku
--FROM dbz
--WHERE Character LIKE '%Goku%';

--Q12 Display Units with Super AGL and thier Leader Skills
--SELECT Title,Character,LeaderSkill
--FROM dbz
--WHERE SALevel = '20/20'
--AND Type = 'Super AGL';

--Q13 Display All Passive skills that increase KI Sidenote Database from kaggle includes images to what ki they increase hence the Large amount of Links in the output
--SELECT Title,Character, PassiveSkill
--FROM dbz
--WHERE PassiveSkill LIKE '%Ki +%';

--Q14 Display Amount Of Lr rarities in the database
--SELECT COUNT(Rarity) as Total_LR
--FROM dbz
--WHERE Rarity = 'LR';

--Q15 Display Amount of Types for each Unique Type
--SELECT Count(Character), Type
--FROM dbz
--GROUP BY Type;

--Q16 Display Units Who are of type Extreme INT and have SA Level 10/10 in Alphabetical Order
--SELECT DISTINCT dbz.Title,dbz.Character
--FROM dbz, (SELECT DISTINCT dbz.Title,dbz.Character
--            FROM dbz
--            WHERE Type = 'Extreme INT')
--            WHERE SALevel = '10/10';

--Q17 When users leave thier comments on team they made for teams
--INSERT 
--INTO Users (UserId,UserName,UserComment)
--VALUES ('?','?','?');

--Q18 Display All Characters
--SELECT DISTINCT character
--FROM dbz;

--Q19 Display All Units Who Have a Transformation
--SELECT DISTINCT Title,Character,Rarity,Id
--FROM dbz
--WHERE Id > 40000;

--Q20 Display All Different Transformatin Types
--SELECT DISTINCT TransformationType
--FROM dbz;

-----------------------------------------------------------------------------
--New Queries

--Q1 Display all Super AGL Types
--SELECT Title, Character
--FROM dbz
--WHERE Type = 'Super AGL';

--Q2 Insert Character ID's To create your team
--INSERT INTO Team (LeaderCharacter,Character2,Character3,Character4,Character5,Character6,Team_ID)
--VALUES (1321,1380,1439,1528,1331,1539,1);

--Q3 Update Unit to show you change the character from that team
-- UPDATE Team
-- SET Character5 = '1376'
-- WHERE Team_ID = 1;

--Q4 Delete Unit to remove it from the Team
--DELETE 
--FROM Team
--WHERE Id = 1321;

--Q5 Selecting the team you want so it displays the units ID
-- SELECT LeaderCharacter,Character2,Character3,Character4,Character5,Character6
-- FROM Dokkan_Cards,Team
-- WHERE Team.Team_ID = 2
-- LIMIT 1;

--Q6 Select Post using the Username from Users
-- SELECT P_UserName
-- FROM Posts,Users
-- WHERE Users.UserName = Posts.P_UserName;

--Q7 Display How many Likes A ussr got on his comment
--SELECT CommentLikes
--FROM Comment_Likes,Comments,Posts,Users
--WHERE Users

--Q8 total Units whos type are Extreme AGL and Extreme INT

--Q9 Unit With Highest EZA Attack
--SELECT Title,Character,MAX(EZAAttack)
--FROM Dokkan_Cards;

--Q10 # of Comments made by a user on posts

--Q11 List of Links from a Users Team

--Q12 Bring up Most Liked Post or Comment?

--Q13 Display Units that have a Transformation type of Fusion
--SELECT Title, Character, TransformationType
--FROM Dokkan_Cards
--WHERE TransformationType LIKE '%Fusion%';

--Q14 Displays Count of Units with Type Extreme AGL who have the Link Fierce Battle
--SELECT COUNT(Character) as Units_With_Fierce_Battle_and_ExtremeAGL
--FROM Dokkan_Cards
--WHERE Type = 'Extreme AGL'
--AND Link LIKE '%Fierce Battle%';

--Q15 Display How many Characters Share the Name Goku Or Vegeta PS Gotta work on this
--SELECT COUNT(Character) as Names_With_Goku
--FROM Dokkan_Cards
--WHERE Character LIKE '%Goku%'
--UNION ALL
--SELECT COUNT(Character) as Names_With_Vegeta
--FROM Dokkan_Cards
--WHERE Character LIKE '%Vegeta%';

--Q16 Display Count of Followers For User

--Q17 Display all UserNames who Follow a User

--Q18 Display Sum of HP, ATK, DEF for A Posts Team and the User who posted it

--Q19 Display All things a User Liked whether it be Comments or Posts

--Q20 Select All Units From a Team who dont have a specific Link or Type From A Post
